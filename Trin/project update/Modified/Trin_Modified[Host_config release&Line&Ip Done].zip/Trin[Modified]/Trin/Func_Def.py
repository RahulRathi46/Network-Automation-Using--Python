import ConfigParser
import paramiko
import time


def config(i):
    if i=="c":
        config = ConfigParser.ConfigParser()
        config.readfp(open(r'/home/vx/Desktop/trin.cfg'))
        return config
    else:
        config = ConfigParser.ConfigParser()
        config.readfp(open(r'/home/vx/Desktop/trin.ini'))
        return config


def connect_ssh(ip,u,p,x,r):
   
    L=0
    for l in range(int(r)):
        if l==0:
                
            # Create instance of SSHClient object
            ssh = paramiko.SSHClient()
        
            # Automatically add untrusted hosts (make sure okay for security policy in your environment)
            ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        
            # initiate SSH connection
            ssh.connect(ip, username=u, password=p)
            
            # establish an 'interactive session'
            remote_ssh = ssh.invoke_shell()
            
            # Turn off paging
            remote_ssh.send("terminal length 0 \n")
            
            
            
    
    
            print "SSH connection established to %s " % ip +"&"+" Interactive SSH session established \n"

        else :
            
            
            #Typing SSH CMD
            remote_ssh.send("ssh "+"-l "+ config("c").get("Host_config", "username%d"%l)+" " +config("c").get("Host_config", "host%d"%l)+"\n")
            time.sleep(2)
            
            #Entering password
            remote_ssh.send(config("c").get("Host_config", "password%d"%l)+"\n")
            time.sleep(1)
            
            # Turn off paging
            remote_ssh.send("terminal length 0 \n")
            
            #assigning host no to determne config
            L=L+1
            
            
    #action list
    to_do(remote_ssh,x,ssh,L)
    

    
    
    
def signal(x,w):
    if x=="g":
        w.send("config t\n")
        time.sleep(2)
    else :
        w.send("en\n")
        time.sleep(1)
        w.send("amount\n")
        time.sleep(1)
   





def to_do(w,o,ssh,L):
    if o=="1":
        signal("u", w)
        signal("g", w)
        interface(w,L)
        
    elif o=="2":
        signal("u", w)
        signal("g", w)
        line(w,L)
        get_state(w,"2")
        
    elif o=="3":
        print("\n#########################################################")
        print ("1.Interface "+"2.running-config "+"3. startup-config")
        print ("#########################################################\n")
        x=raw_input("Enter the choice : ")
        print "\n"
        signal("u", w)
        get_state(w,x)
    elif o=="4":
        print("\n###############################################################################")
        print ("1.Save to startup-Config "+"  "+"2. Get back Running-Config from Startup-Config")
        print ("###############################################################################\n")
        x=raw_input("Enter the choice : ")
        print "\n"
        signal("u", w)
        save(w,x)
        
    else:
        return 0
        
        
        
    print w.recv(100000)
    #session terminiting aftwer every task { applied for security } { you can inscres speed of excution of script by removing this }
    ssh.close()
    




def line(w,L):
    #intiallizing of task 
    for l in range(int(config("c").get("Host%d_Line_config"%L, "no_of_task"))) :
        
        #sending frist line cmd
        w.send("line "+ config("c").get("Host%d_Line_config"%L, "line%d"%l) +"\n")
        time.sleep(1)
        
        #sending login cmd 
        if "login" in config("c").get("Host%d_Line_config"%L, "login%d"%l) :
            w.send(config("c").get("Host%d_Line_config"%L, "login%d"%l) +"\n")
        else :
            w.send( config("c").get("Host%d_Line_config"%L, "login%d"%l) +"\n")
        
        #sending password cmd
        if config("c").get("Host%d_Line_config"%L, "password%d"%l)=="-1" :
            w.send("exit\n")
        else :
            w.send("password "+ config("c").get("Host%d_Line_config"%L, "password%d"%l) +"\n")
        
        #sending  exit
        w.send("exit\n")
        time.sleep(2)
        
    #sending back to user-mode signal
    w.send("exit\n")

def interface(w,L):
    
    #intiallizing of task 
    for l in range(int(config("c").get("Host%d_Interface_config"%L, "no_of_task"))) :
        
        
        # sending interface cmd
        w.send("interface "+ config("c").get("Host%d_Interface_config"%L, "interface%d"%l) +"\n")
        time.sleep(1)
        
        #configuring ip & subnet
        w.send("ip address "+ config("c").get("Host%d_Interface_config"%L, "ip_subnet%d"%l) +"\n")
        time.sleep(1)
        
        #sending state config
        if config("c").get("Host%d_Interface_config"%L, "state%d"%l) =="up":
            w.send("no sh"+"\n")
            time.sleep(1)
            
        else :
            w.send("sh\n")
            time.sleep(1)
    
    
    w.send("exit\n")
    w.send("\n")
    time.sleep(1)
    w.send("exit\n")
    time.sleep(1)
     
   
    
    #sending get_state
    get_state(w,"1")
    
    

    
def get_state(w,x):
    
    #get_state of interface 
    if x=="1":
        w.send(config("d").get("Get_state", "ip_interface")+"\n")
        time.sleep(2)
    #get state of running state
    elif x=="2":
        w.send(config("d").get("Get_state", "running-config")+"\n")
        time.sleep(5)
    #get state of startup
    elif x=="3":
        w.send(config("d").get("Get_state", "startup-config")+"\n")
        time.sleep(5)
        
      
def save(w,x):
    
    #get state save to Startup-config
    if x=="1":
        w.send(config("d").get("Save_change", "to_startup-config")+"\n")
        w.send("\n")
        
    #get state save to running-config
    elif x=="2":
        w.send(config("d").get("Save_change", "to_running-config")+"\n")
        w.send("\n")
   
    time.sleep(5)
    
    
    

    
